package com.ite4demo.intents;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class DidYouKnow extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_did_you_know2);
        String DidYouKnow;
        Bundle extras = getIntent().getExtras();
        DidYouKnow = extras.getString("DidYouKnow");

        setContentView(R.layout.activity_did_you_know2);

        Toast.makeText(this, DidYouKnow + " selected", Toast.LENGTH_LONG).show();


        TextView tv2 = (TextView) findViewById(R.id.textView2);


        tv2.setText(DidYouKnow);
    }
}
