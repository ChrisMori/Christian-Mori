package com.ite4demo.intents;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class CarBrands extends ListActivity{

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //setContentView(R.layout.activity_main);
        /*
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        */
        String[] values = new String[] { "Toyota","Mitsubishi","Nissan"};
        // Use your own layout
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                R.layout.rowlayout, R.id.label, values);
        setListAdapter(adapter);
    }

    protected void onListItemClick(ListView l, View v, int position, long id) {
        String item = (String) getListAdapter().getItem(position);
        //Toast.makeText(this, item + position + " selected", Toast.LENGTH_LONG).show();
        Intent intent;
        switch (position) {

            case 0:
                intent = new Intent(CarBrands.this, Toyota.class);
                intent.putExtra("Toyota", item);
                startActivityForResult(intent, 1);
                Toast.makeText(this, item + " " + position + " selected", Toast.LENGTH_LONG).show();
                break;
            case 1:
                intent = new Intent(CarBrands.this, Mitsubishi.class);
                intent.putExtra("Mitsubishi", item);
                startActivityForResult(intent, 1);
                Toast.makeText(this, item + " " + position + " selected", Toast.LENGTH_LONG).show();
                break;
             case 2:
                intent = new Intent(CarBrands.this, Nissan.class);
                intent.putExtra("Nissan", item);
                startActivityForResult(intent, 1);
                Toast.makeText(this, item + " " + position + " selected", Toast.LENGTH_LONG).show();
                break;

        }


    }
}
